<img id="logolycee" src="img/logolycee.png"/>
<div class="logo"><a href="index.php">FAQs</a></div>
<div class="power"><a href="identification.php">Connecter</a></div>