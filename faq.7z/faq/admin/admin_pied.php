		</div>
	</div>

	<div class="credit">
		<?php include('../credit.php'); ?>
	</div>
</body>
</html>