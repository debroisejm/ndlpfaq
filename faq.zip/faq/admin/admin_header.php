<img id="logolycee" src="../img/logolycee.png"/>
<div class="logo"><a href="espace_admin.php">FAQs Espace admin</a></div>
<div class="power"><a href="../deconnection.php">Déconnecter</a></div>