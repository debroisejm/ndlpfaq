<html>
<head>
	<title>Changement du traitement</title>
	<meta charset="UTF-8">
</head>
<body>


<?php

		$Id_Form = $_post['id'];
		echo $Id_Form;
		
	?>
</body>
</html>