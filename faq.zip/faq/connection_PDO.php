<?php 
	$bdd = new PDO('mysql:host=localhost;dbname=site_faq;charset=utf8', 'root', 'password');
?>
